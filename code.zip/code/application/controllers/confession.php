<?php
class Confession extends CI_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->library('javascript');			
	}	
	
	function index()
	{
		$data['query']=$this->db->get('confessions');
		$data['title']="Confession Room";
		$this->load->view('confession_view',$data);
	}
	
	function insert()
	{
		$who = $this->input->post('who');
		$message = $this->input->post('msg');
		$data=array('who'=>$who,'message'=>$message);
		$resultArray["who"] = $who;
            	$resultArray["msg"] = $message;
		$this->db->insert('confessions',$data);
		$this->output->set_content_type('application/json')->set_output(json_encode($resultArray));//send json object as output	
		//redirect('confession');
		
	}
	function update()
	{	$ajxcount=$this->input->post('count');
		$count=$this->db->count_all_results('confessions');
		$count--;		
		if($ajxcount==0)
			{
				$resultArray["count"]=$count;
				$this->output->set_content_type('application/json')->set_output(json_encode($resultArray));	
			}
		else if($ajxcount==$count)
			{
				$resultArray["count"]=$count;
				$this->output->set_content_type('application/json')->set_output(json_encode($r));
			}
		else if($ajxcount!=$count)
		{		//set counter for last insert
			$query=$this->db->get('confessions',1,$count);
			$resultArray = array();
			foreach($query->result() as $row)	//get row	
			{
			$resultArray["who"] = $row->who;
		    	$resultArray["msg"] = $row->message;
			$resultArray["count"]=$count;
			}
		    	//$resultArray["who"] = $row["who"];
		    	//$resultArray["msg"] = $row["message"];
			//$resultArray['who']="nick";
			//$resultArray['msg']="hello";
			$this->output->set_content_type('application/json')->set_output(json_encode($resultArray));
		}
	}
}
?>
