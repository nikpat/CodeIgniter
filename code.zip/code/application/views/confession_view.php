<html>
<head>
<title><?php echo $title;?></title>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
<script src="/code/script/jquery.js"></script>
<style type="text/css">
div.ex
{
	border: 1px solid gray;
    margin: 0;
    padding: 10px;
    position: fixed;
    left: 600px;
    top: 50px;
	overflow-x:;
	overflow-y:scroll;
    width: 700px;
    height: 460px;
	word-wrap:break-word;
	margin-left:auto;
	margin-right:auto;
	background-color: white;
	text-align:left;
	padding:8px;
	
}
div.formpos
{
	left: 20px;
    position: fixed;
    top: 200px;
}
div.rela
{
	position:relative;
}
</style>

<script type="text/javascript">
$(document).ready(function(){
 $("#msg").scrollTop($("#msg")[0].scrollHeight);
});
</script>
<script type="text/javascript">
$(document).ready(function(){
$("button").click(function(){
var m = document.getElementById("from").value;
var n = document.getElementById("story").value;
$("input#from").val("");
$("#story").val("");
var data={
'who':m,'msg':n};
  $.ajax({type:"POST",url:"/code/confession/insert",data:data, success:function(resultData){
	var resultObject = eval(resultData);
	//$('#msg').append('<a style="font-size:22px;">'+ resultObject.who + '</a> : ' +resultObject.msg + '<br> <hr>');
	$("#msg").scrollTop($("#msg")[0].scrollHeight);
  }});
});
});
</script>

<script type="text/javascript">
var ajxcount=0;
var checkTable = setInterval(function(){
 $.ajax({
     type: "POST",
     url: "/code/index.php/confession/update",
     data:  {'count':ajxcount},
     success: function(resultData){
     var resultObject = eval(resultData);
     ajxcount=resultObject.count;
     if(!resultObject.who)
	{
		return false;
	}
     else
     	{
	$('#msg').append('<a style="font-size:22px;">'+ resultObject.who + '</a> : ' +resultObject.msg + '<br> <hr>');
     	$("#msg").scrollTop($("#msg")[0].scrollHeight);
	}
     //alert('who: ' + resultObject.who + ' - field1: ' + resultObject.msg);       
                              // if this is successful, return the id from the mysql record in post and generate the dialog url based on this id, eg if id returned is 5, then url will be page.php?id=5 (i need this for generating the dialog modal based on a url
     }
     }); 
      }, 1000);
</script>


</head>

<body background="/code/images/bgimage.jpg">
<h1 align="left">Confession Room</h1>

<h3 align="left">This is an application to give people a platform to speak their<br> hearts out without revealing their identities.</h3>
<div class="ex" id="msg">
<?php foreach($query->result() as $row): ?>
<a style="font-size:22px;">
<?php if ($row->who=="")
       echo "Anonyomus";
      else
	echo $row->who
?>
</a>
 : <?=$row->message?>
<hr>
<?php endforeach;?>
</div>
<div class="formpos">
<?php //form_open('confession/insert');?>
<p>
From:<br>
<input type="text" name="who" id="from"/><br>
Story:<br>
<textarea name="message" rows="15" cols="60" id="story"></textarea><br>
<button>Share</button>
</p>

</div>
</body>
</html>
